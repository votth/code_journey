// Prints char

#include <stdio.h>

int main(void)
{
    char c = '#';

    printf("%c\n", c);
}
